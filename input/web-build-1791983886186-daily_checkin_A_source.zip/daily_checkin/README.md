# 每日打卡（Android）A 版项目

一个原生 Android 极简每日打卡应用的初始项目。

## 当前包含
- 黑白灰极简界面
- 每天重复的事项，以及仅当天有效的临时事项
- 每日完成状态按日期单独保存，旧日期记录不会自动覆盖
- 可从桌面小组件点击事项切换完成状态（当前组件最多显示 5 项）
- 可设置每日通知提醒时间
- 本地 SharedPreferences 保存数据，不需要账号或云端服务

## 构建
此项目需要 Android Studio / Android SDK 和网络可用的 Gradle 依赖解析环境。
1. 在 Android Studio 中打开本文件夹 `daily_checkin`。
2. 等待 Gradle Sync 完成。
3. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. APK 通常会生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 重要说明
- 这是 A 版初始源码，尚未在真实安卓设备上构建或测试。
- 本执行环境当前没有 Android SDK 或 Gradle，因此无法在此处直接生成/验证 APK。不要将源码压缩包误认为可安装 APK。
- Android 13 及以上版本需要允许通知权限；具体系统的省电策略可能影响定时提醒的准时程度。
- 桌面小组件的显示数量受小组件尺寸限制，当前最多显示 5 个事项。
- 更新已安装版本时，需要保持 applicationId 和签名一致，并递增 versionCode；升级前建议备份数据。
