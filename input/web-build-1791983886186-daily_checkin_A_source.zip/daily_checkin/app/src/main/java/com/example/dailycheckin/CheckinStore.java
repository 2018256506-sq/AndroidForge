package com.example.dailycheckin;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Calendar;

final class CheckinStore {
    static final String PREFS = "daily_checkin";
    static final String ITEMS = "items_json";
    static final String ACTION_TOGGLE = "com.example.dailycheckin.TOGGLE";
    private CheckinStore() {}
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    static String displayDate() { return new SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()); }
    static ArrayList<JSONObject> allItems(Context c) {
        ArrayList<JSONObject> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(prefs(c).getString(ITEMS, "[]")); for (int i=0; i<a.length(); i++) out.add(a.getJSONObject(i)); }
        catch (Exception ignored) {}
        return out;
    }
    static ArrayList<JSONObject> items(Context c) {
        ArrayList<JSONObject> out = new ArrayList<>(); String today = today();
        for (JSONObject o : allItems(c)) try { String day = o.optString("day", ""); if (day.isEmpty() || day.equals(today)) out.add(o); } catch (Exception ignored) {}
        return out;
    }
    static void saveAllItems(Context c, ArrayList<JSONObject> items) {
        JSONArray a = new JSONArray(); for (JSONObject o : items) a.put(o);
        prefs(c).edit().putString(ITEMS, a.toString()).apply(); refreshWidgets(c);
    }
    static void saveItems(Context c, ArrayList<JSONObject> visible) {
        ArrayList<JSONObject> all = allItems(c); String today = today();
        all.removeIf(o -> today.equals(o.optString("day", "")));
        all.addAll(visible); saveAllItems(c, all);
    }
    static boolean isDone(Context c, String id, String date) { return prefs(c).getBoolean("done_" + date + "_" + id, false); }
    static void setDone(Context c, String id, String date, boolean done) {
        prefs(c).edit().putBoolean("done_" + date + "_" + id, done).apply(); refreshWidgets(c);
    }
    static void refreshWidgets(Context c) {
        Intent i = new Intent(c, HabitWidgetProvider.class); i.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int[] ids = android.appwidget.AppWidgetManager.getInstance(c).getAppWidgetIds(new android.content.ComponentName(c, HabitWidgetProvider.class));
        i.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids); c.sendBroadcast(i);
    }
    static void scheduleReminder(Context c, int hour, int minute) {
        prefs(c).edit().putInt("reminder_hour", hour).putInt("reminder_minute", minute).putBoolean("reminder_enabled", true).apply();
        scheduleSavedReminder(c);
    }
    static void scheduleSavedReminder(Context c) {
        SharedPreferences p = prefs(c);
        if (!p.getBoolean("reminder_enabled", false)) return;
        Calendar when = Calendar.getInstance(); when.set(Calendar.HOUR_OF_DAY, p.getInt("reminder_hour", 20)); when.set(Calendar.MINUTE, p.getInt("reminder_minute", 0)); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
        if (!when.after(Calendar.getInstance())) when.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 731, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }
    }
}
