package com.example.dailycheckin;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.UUID;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView progress;
    private int ink = 0xFF222222, muted = 0xFF777777;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 90);
        buildUi(); renderItems(); CheckinStore.scheduleSavedReminder(this);
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(ink); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFECECE8)); return b; }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(0xFFFAFAF8);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(28), dp(22), dp(24)); scroll.addView(root);
        TextView date = text(CheckinStore.displayDate(), 11, muted); date.setLetterSpacing(0.08f); root.addView(date);
        TextView title = text("每日打卡", 28, ink); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2); tp.topMargin = dp(8); root.addView(title, tp);
        TextView subtitle = text("慢慢来，完成一项也很好。", 14, muted); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(5); sp.bottomMargin = dp(24); root.addView(subtitle, sp);
        progress = text("今天的事项", 15, ink); progress.setTypeface(Typeface.DEFAULT, Typeface.BOLD); root.addView(progress);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10); lp.bottomMargin = dp(18); root.addView(list, lp);
        Button add = button("＋  添加事项"); add.setOnClickListener(v -> addItem()); root.addView(add, new LinearLayout.LayoutParams(-1, dp(48)));
        Button reminder = button("设置每日提醒时间"); LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48)); rp.topMargin = dp(10); reminder.setOnClickListener(v -> chooseReminder()); root.addView(reminder, rp);
        TextView note = text("事项与记录保存在本机。桌面小组件可单独添加到主屏幕。", 12, muted); LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(20); root.addView(note, np);
        setContentView(scroll);
    }
    private void renderItems() {
        list.removeAllViews(); ArrayList<JSONObject> items = CheckinStore.items(this); int done = 0; String today = CheckinStore.today();
        for (JSONObject item : items) try { if (CheckinStore.isDone(this, item.getString("id"), today)) done++; } catch (Exception ignored) {}
        progress.setText(items.isEmpty() ? "今天的事项" : "今天的事项    " + done + "/" + items.size());
        if (items.isEmpty()) { TextView empty = text("还没有事项，添加一项开始吧。", 14, muted); empty.setPadding(0, dp(18), 0, dp(18)); list.addView(empty); return; }
        for (JSONObject item : items) {
            try {
                String id = item.getString("id"), title = item.getString("title"); boolean isDone = CheckinStore.isDone(this, id, today);
                LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4), dp(8), dp(4), dp(8));
                CheckBox check = new CheckBox(this); check.setButtonTintList(android.content.res.ColorStateList.valueOf(isDone ? 0xFF555555 : 0xFF999999)); check.setChecked(isDone);
                TextView label = text(title, 15, isDone ? muted : ink); if (isDone) label.setPaintFlags(label.getPaintFlags() | 0x10);
                LinearLayout.LayoutParams labelp = new LinearLayout.LayoutParams(0, -2, 1); labelp.leftMargin = dp(8); row.addView(check); row.addView(label, labelp);
                TextView more = text("⋯", 24, muted); more.setPadding(dp(12), 0, dp(4), 0); row.addView(more);
                check.setOnCheckedChangeListener((button, checked) -> { CheckinStore.setDone(this, id, today, checked); renderItems(); });
                more.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(new String[]{"删除事项", "取消"}, (d, which) -> { if (which == 0) deleteItem(id); }).show());
                View line = new View(this); line.setBackgroundColor(0xFFE6E6E1); list.addView(row, new LinearLayout.LayoutParams(-1, -2)); list.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            } catch (Exception ignored) {}
        }
    }
    private void addItem() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("例如：阅读 10 分钟");
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(dp(22), dp(8), dp(22), 0); wrap.addView(input, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("添加事项").setView(wrap).setPositiveButton("每天重复", (d, w) -> saveNewItem(input.getText().toString().trim(), false)).setNeutralButton("仅今天", (d, w) -> saveNewItem(input.getText().toString().trim(), true)).setNegativeButton("取消", null).show();
    }
    private void saveNewItem(String title, boolean todayOnly) {
        if (title.isEmpty()) { Toast.makeText(this, "先写下事项名称", Toast.LENGTH_SHORT).show(); return; }
        ArrayList<JSONObject> all = CheckinStore.allItems(this);
        try { JSONObject o = new JSONObject(); o.put("id", UUID.randomUUID().toString()); o.put("title", title); o.put("day", todayOnly ? CheckinStore.today() : ""); all.add(o); CheckinStore.saveAllItems(this, all); renderItems(); }
        catch (Exception ignored) {}
    }
    private void deleteItem(String id) {
        ArrayList<JSONObject> all = CheckinStore.allItems(this); ArrayList<JSONObject> keep = new ArrayList<>();
        for (JSONObject o : all) if (!id.equals(o.optString("id"))) keep.add(o);
        CheckinStore.saveAllItems(this, keep); renderItems();
    }
    private void chooseReminder() {
        android.content.SharedPreferences p = CheckinStore.prefs(this); int hour = p.getInt("reminder_hour", 20), minute = p.getInt("reminder_minute", 0);
        new TimePickerDialog(this, (view, h, m) -> { CheckinStore.scheduleReminder(this, h, m); Toast.makeText(this, String.format("每日提醒已设为 %02d:%02d", h, m), Toast.LENGTH_SHORT).show(); }, hour, minute, true).show();
    }
}
