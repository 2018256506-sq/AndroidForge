package com.example.dailycheckin;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.util.ArrayList;

public class HabitWidgetProvider extends AppWidgetProvider {
    private static final int[] ROW_IDS = {R.id.widget_item_0, R.id.widget_item_1, R.id.widget_item_2, R.id.widget_item_3, R.id.widget_item_4};
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (CheckinStore.ACTION_TOGGLE.equals(intent.getAction())) {
            String id = intent.getStringExtra("item_id");
            String date = intent.getStringExtra("date");
            if (id != null && date != null) CheckinStore.setDone(context, id, date, !CheckinStore.isDone(context, id, date));
            updateAll(context, AppWidgetManager.getInstance(context));
        } else if (Intent.ACTION_DATE_CHANGED.equals(intent.getAction()) || Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction())) {
            updateAll(context, AppWidgetManager.getInstance(context));
        }
    }
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }
    static void updateAll(Context context, AppWidgetManager manager) {
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HabitWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }
    private static void updateOne(Context c, AppWidgetManager manager, int widgetId) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_habits);
        v.setTextViewText(R.id.widget_date, CheckinStore.displayDate());
        ArrayList<JSONObject> items = CheckinStore.items(c);
        String date = CheckinStore.today(); int shown = Math.min(items.size(), ROW_IDS.length); int doneCount = 0;
        for (JSONObject item : items) try { if (CheckinStore.isDone(c, item.getString("id"), date)) doneCount++; } catch (Exception ignored) {}
        v.setTextViewText(R.id.widget_progress, items.isEmpty() ? "今日打卡" : "今日打卡   " + doneCount + "/" + items.size());
        for (int i=0; i<ROW_IDS.length; i++) {
            int row = ROW_IDS[i];
            if (i >= shown) { v.setViewVisibility(row, View.GONE); continue; }
            JSONObject item = items.get(i);
            try {
                String itemId = item.getString("id"); String title = item.getString("title"); boolean done = CheckinStore.isDone(c, itemId, date);
                v.setViewVisibility(row, View.VISIBLE); v.setTextViewText(row, (done ? "✓  " : "○  ") + title);
                v.setTextColor(row, done ? 0xFF888888 : 0xFF222222);
                Intent toggle = new Intent(c, HabitWidgetProvider.class); toggle.setAction(CheckinStore.ACTION_TOGGLE); toggle.putExtra("item_id", itemId); toggle.putExtra("date", date);
                PendingIntent pi = PendingIntent.getBroadcast(c, (widgetId * 1000) + i + 1, toggle, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                v.setOnClickPendingIntent(row, pi);
            } catch (Exception ignored) {}
        }
        if (items.isEmpty()) {
            v.setViewVisibility(R.id.widget_item_0, View.VISIBLE); v.setTextViewText(R.id.widget_item_0, "○  打开 App 添加事项");
            Intent open = new Intent(c, MainActivity.class); PendingIntent pi = PendingIntent.getActivity(c, widgetId, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.widget_item_0, pi);
        }
        Intent open = new Intent(c, MainActivity.class); PendingIntent openPi = PendingIntent.getActivity(c, 9000 + widgetId, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_date, openPi); v.setOnClickPendingIntent(R.id.widget_progress, openPi);
        manager.updateAppWidget(widgetId, v);
    }
}
