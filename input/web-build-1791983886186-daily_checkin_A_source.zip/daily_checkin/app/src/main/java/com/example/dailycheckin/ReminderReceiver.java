package com.example.dailycheckin;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.util.ArrayList;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String channelId = "daily_checkin_reminder";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) nm.createNotificationChannel(new NotificationChannel(channelId, "每日打卡提醒", NotificationManager.IMPORTANCE_DEFAULT));
        ArrayList<JSONObject> items = CheckinStore.items(context); int done = 0;
        for (JSONObject item : items) try { if (CheckinStore.isDone(context, item.getString("id"), CheckinStore.today())) done++; } catch (Exception ignored) {}
        Intent open = new Intent(context, MainActivity.class); PendingIntent pi = PendingIntent.getActivity(context, 812, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String message = items.isEmpty() ? "花一点时间添加今天的事项。" : "今天完成了 " + done + "/" + items.size() + " 项，记得来打卡。";
        if (nm != null) {
            NotificationCompat.Builder b = new NotificationCompat.Builder(context, channelId).setSmallIcon(android.R.drawable.ic_menu_today).setContentTitle("每日打卡").setContentText(message).setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
            try { nm.notify(731, b.build()); } catch (SecurityException ignored) {}
        }
        CheckinStore.scheduleSavedReminder(context);
    }
}
